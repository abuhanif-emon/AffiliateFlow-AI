# Final quality check

Check the content for:
- unsupported product claims,
- invented prices, discounts, ratings, or reviews,
- false first-person testing claims,
- missing or unclear affiliate disclosure,
- copyrighted or unlicensed images/music/footage,
- unreadable captions or unsafe text placement,
- misleading comparison or guarantee,
- platform-specific length/format issues.

Return PASS/NEEDS REVIEW with specific fixes. Never mark unsupported claims as verified.
