# Content package prompt

Create platform-specific short-form affiliate content for YouTube Shorts, TikTok, and Instagram Reels.

Requirements:
- Base every product statement only on supplied product facts.
- Do not invent prices, discounts, ratings, reviews, availability, or personal experience.
- Avoid exaggerated guarantees and misleading urgency.
- Provide: 3 hooks, a 20–40 second script, scene-by-scene storyboard, on-screen text, caption, title, relevant hashtags, and a plain-language affiliate disclosure.
- Use a helpful, balanced tone. Include one limitation or “check before buying” point when the facts allow it.
- Output in the requested language.
