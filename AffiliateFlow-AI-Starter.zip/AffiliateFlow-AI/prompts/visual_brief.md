# Visual brief prompt

Create a shot list for an original, polished product explainer. Do not imitate a brand's official advertisement or imply that generated scenes are real product photographs. Distinguish:
1. actual product photos supplied by the user and licensed for use,
2. generic illustrative scenes,
3. text/diagram overlays.

Never fabricate product details in an image. Do not remove watermarks or suggest using images without permission.
