# Compliance checklist

- Disclose affiliate relationships clearly and near the recommendation.
- Follow the affiliate program's current operating agreement and each platform's policies.
- Use only images, video, music, fonts, and voice assets that you own or have permission to use.
- Do not fabricate reviews, ratings, discounts, scarcity, product testing, or endorsements.
- Verify all product facts with official, current sources before publishing.
- Do not expose API keys. Keep `.env` private and excluded from Git.
- Review eligibility and age requirements for any affiliate program before applying.
