# Workflow

1. User supplies an affiliate destination URL and factual product details.
2. AI drafts a fact-separated brief and content package.
3. User checks facts against official sources.
4. User supplies images/footage they own or are licensed to use.
5. App generates a voice-over audio track.
6. App assembles a basic 9:16 video draft.
7. User reviews the video, disclosure, and platform rules, then publishes manually.

The URL is not scraped in this MVP. This avoids treating an inaccessible or dynamically rendered product page as verified evidence.
